/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.se2.meteocal.entity;

/**
 *Group class containing groups definitions.
 * @author edo
 */
public class Group {
    public static final String USERS = "USERS";
}
