/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.se2.meteocal.enums;

/**
 * Enum listing the possible types of events
 *
 * @author edo
 */
public enum EventType {
    INDOOR,
    OUTDOOR
}
